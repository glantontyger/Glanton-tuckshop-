package za.co.glanton.tuckshop;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Context;
import android.content.SharedPreferences;

public class MainActivity extends Activity {
    private WebView webView;
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.addJavascriptInterface(new StorageBridge(this), "AndroidStorage");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    public static class StorageBridge {
        private final SharedPreferences prefs;
        StorageBridge(Context context) { prefs = context.getSharedPreferences("glanton_tuckshop", Context.MODE_PRIVATE); }
        @JavascriptInterface public String loadData() { return prefs.getString("stock", "[]"); }
        @JavascriptInterface public void saveData(String json) { prefs.edit().putString("stock", json).apply(); }
    }
}
