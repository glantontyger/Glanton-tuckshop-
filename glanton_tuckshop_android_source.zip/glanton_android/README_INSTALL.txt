GLANTON TUCKSHOP — ANDROID APK BUILD

This is the Android project source. This chat environment does not have the Android SDK/Gradle build environment needed to compile and sign an APK directly. The included GitHub Actions workflow can build a debug APK using GitHub's hosted build runner.

BUILD APK USING FREE GITHUB ACTIONS
1. On your phone or computer, sign in/create a GitHub account at https://github.com.
2. Create a new repository named glanton-tuckshop. Set it to Private if you want to keep your source private.
3. Upload the CONTENTS of this folder to the repository (including the .github folder). You may find it easier on a computer.
4. Open the repository's Actions tab and select "Build Glanton Tuckshop APK".
5. Tap "Run workflow" and wait for the workflow to finish successfully.
6. Open the completed workflow run, scroll to Artifacts, and download "Glanton-Tuckshop-APK". Extract the downloaded artifact ZIP to get app-debug.apk.
7. Transfer app-debug.apk to your Android phone and open it. If prompted, allow your browser or Files app to install unknown apps, then install it. Only install APKs you built from your own repository.

NOTES
- This is an unsigned-for-store debug APK suitable for direct personal testing, not Play Store publication.
- App data is intended to be kept locally on your device. Back up stock data regularly.
- The app currently bundles the web stock UI inside a native Android WebView. A follow-up refinement should route data saving through the native StorageBridge and implement native backup/import intents; the first source draft currently needs that persistence integration before being considered production-ready.
